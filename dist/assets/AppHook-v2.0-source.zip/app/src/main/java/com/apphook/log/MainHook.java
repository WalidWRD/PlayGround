package com.apphook.log;

import android.util.Log;

import io.github.libxposed.api.XposedInterface;
import io.github.libxposed.api.XposedModule;
import io.github.libxposed.api.XposedModuleInterface;

/**
 * نقطة الدخول الحديثة (libxposed 101/102).
 *
 * <p>القواعد المطبقة من طلبك:</p>
 * <ul>
 *   <li>يستخدم {@code getClassLoader()} من {@code PackageReadyParam}
 *       (= lpparam.classLoader) — لا أسماء ثابتة.</li>
 *   <li>يدعم التطبيقات المضغوطة/المحمية: الهوك الأساسي في
 *       {@code onPackageReady} (بعد فك الـ stub واستبدال الـ ClassLoader)،
 *       مع مسح مبكر خفيف في {@code onPackageLoaded}.</li>
 *   <li>يتعامل مع أي إصدار (أقل/أعلى) وبغض النظر عن الحزمة:
 *       سلسلة استراتيجيات + تجاهل آمن عند الاختلاف.</li>
 *   <li>بلا روت: يعمل داخل LSPosed / LSPatch / NPatch / HKP.</li>
 * </ul>
 */
public final class MainHook extends XposedModule {

    public MainHook() {
        super();
    }

    @Override
    public void onModuleLoaded(XposedModuleInterface.ModuleLoadedParam param) {
        SafeHook.attach(this);
        ModuleInfo.logStartup(this);
        try {
            log(Log.INFO, "AppHook", "module loaded in: " + param.getProcessName()
                    + " | framework=" + getFrameworkName() + " " + getFrameworkVersion());
        } catch (Throwable ignored) {}
    }

    @Override
    public void onPackageLoaded(XposedModuleInterface.PackageLoadedParam param) {
        String pkg;
        try {
            pkg = param.getPackageName();
        } catch (Throwable t) {
            return;
        }
        if (!inScope(pkg)) return;
        SafeHook.log("package loaded (early): " + pkg + " — waiting onPackageReady for real ClassLoader");
    }

    @Override
    public void onPackageReady(XposedModuleInterface.PackageReadyParam param) {
        String pkg;
        ClassLoader cl;
        try {
            pkg = param.getPackageName();
            cl = param.getClassLoader(); // <-- lpparam.classLoader الحقيقي (بعد فك الحماية)
        } catch (Throwable t) {
            SafeHook.logError("onPackageReady/params", t);
            return;
        }
        if (!inScope(pkg)) return;
        if (cl == null) {
            SafeHook.logSafe(pkg, "ClassLoader null — abort safely");
            return;
        }
        SafeHook.log("package ready: " + pkg + " | cl=" + cl);
        installAll(this, cl, pkg);
    }

    static void installAll(XposedInterface fw, ClassLoader cl, String pkg) {
        try {
            BillingHook.install(fw, cl);
        } catch (Throwable t) {
            SafeHook.logError("BillingHook", t);
        }
        try {
            RevenueCatHook.install(fw, cl);
        } catch (Throwable t) {
            SafeHook.logError("RevenueCatHook", t);
        }
        try {
            FeatureHook.install(fw, cl, pkg);
        } catch (Throwable t) {
            SafeHook.logError("FeatureHook", t);
        }
        try {
            NetworkHook.install(fw, cl);
        } catch (Throwable t) {
            SafeHook.logError("NetworkHook", t);
        }
        try {
            IntegrityHook.install(fw, cl);
        } catch (Throwable t) {
            SafeHook.logError("IntegrityHook", t);
        }
        SafeHook.log("All hook layers installed for: " + pkg);
    }

    /** نطاق شامل مع استثناءات النظام (يمنع البوت لوب والكراش). */
    static boolean inScope(String pkg) {
        if (pkg == null) return false;
        if (pkg.equals("android")) return false;
        if (pkg.equals("com.android.systemui")) return false;
        if (pkg.equals("com.google.android.gms")) return false;
        if (pkg.equals("com.android.vending")) return false;
        if (pkg.equals(ModuleInfo.PACKAGE)) return false;
        return true; // أي حزمة أخرى — بغض النظر عن الاسم
    }
}
