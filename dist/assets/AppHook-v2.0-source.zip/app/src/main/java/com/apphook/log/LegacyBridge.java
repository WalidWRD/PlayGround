package com.apphook.log;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.lang.reflect.Method;
import java.util.List;

/**
 * جسر legacy يعيد تنفيذ نفس الميزات السبع فوق API القديم
 * (de.robv) — كل Hook داخل try/catch مستقل (PROTECTIVE يدوي).
 */
final class LegacyBridge {
    private LegacyBridge() {}

    static void installAll(XC_LoadPackage.LoadPackageParam lp) {
        ClassLoader cl = lp.classLoader;
        safe(() -> hookBilling(cl));
        safe(() -> hookRevenueCat(cl));
        safe(() -> hookPremium(cl, lp.packageName));
        safe(() -> hookNetwork(cl));
        safe(() -> hookIntegrity(cl));
    }

    private interface Job { void run() throws Throwable; }

    private static void safe(Job j) {
        try {
            j.run();
        } catch (Throwable t) {
            XposedBridge.log("[AppHook/Safe] skipped: " + t);
        }
    }

    private static XC_MethodHook after(HookActionProxyLegacy a) {
        return new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                try {
                    Object r = a.run(p);
                    if (r != After.KEEP) p.setResult(r);
                } catch (Throwable t) {
                    XposedBridge.log("[AppHook/Safe] hook body ignored: " + t);
                }
            }
        };
    }

    private interface HookActionProxyLegacy {
        Object run(XC_MethodHook.MethodHookParam p) throws Throwable;
    }

    private static final class After {
        static final Object KEEP = new Object();
    }

    // --- Billing ---
    private static void hookBilling(ClassLoader cl) {
        hookBoolInt(cl, "com.android.billingclient.api.Purchase",
                "getPurchaseState", 0, "[Billing] getPurchaseState");
        hookBoolInt(cl, "com.android.billingclient.api.Purchase",
                "isAcknowledged", true, "[Billing] isAcknowledged");
        hookBoolInt(cl, "com.android.billingclient.api.BillingClient",
                "isReady", true, "[Billing] isReady");
        hookWatch(cl, "com.android.billingclient.api.Purchase$PurchasesResult",
                "getPurchasesList", "[Billing] getPurchasesList");
        try {
            Class<?> bc = XposedHelpers.findClass(
                    "com.android.billingclient.api.BillingClient", cl);
            for (Method m : bc.getDeclaredMethods()) {
                if (!m.getName().equals("queryPurchasesAsync")) continue;
                try {
                    XposedBridge.hookMethod(m, after(p -> {
                        XposedBridge.log("[AppHook] [Billing] queryPurchasesAsync");
                        return After.KEEP;
                    }));
                } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
    }

    // --- RevenueCat ---
    private static void hookRevenueCat(ClassLoader cl) {
        hookBoolInt(cl, "com.revenuecat.purchases.EntitlementInfo",
                "isActive", true, "[Billing] RevenueCat.isActive");
        try {
            Class<?> c = XposedHelpers.findClass(
                    "com.revenuecat.purchases.EntitlementInfo", cl);
            for (Method m : c.getDeclaredMethods()) {
                if (m.getName().toLowerCase().contains("billingissue")) {
                    try {
                        XposedBridge.hookMethod(m, after(p -> {
                            if (p.getResult() != null) return null;
                            return After.KEEP;
                        }));
                    } catch (Throwable ignored) {}
                }
            }
        } catch (Throwable ignored) {}
    }

    // --- Premium flags ---
    private static void hookPremium(ClassLoader cl, String pkg) {
        String[] cands = {pkg + ".UserInfo", pkg + ".User",
                pkg + ".model.User", pkg + ".data.User"};
        String[] tokens = {"isPremium", "isVip", "isPro", "isSubscribed",
                "hasPremium", "hasVip", "isPaid", "isMember", "isGold"};
        for (String cn : cands) {
            Class<?> c;
            try {
                c = XposedHelpers.findClass(cn, cl);
            } catch (Throwable ignored) {
                continue;
            }
            for (String tk : tokens) {
                for (Method m : c.getDeclaredMethods()) {
                    try {
                        if (!m.getName().equalsIgnoreCase(tk)
                                && !m.getName().toLowerCase().contains(tk.toLowerCase())) continue;
                        if (m.getParameterTypes().length != 0) continue;
                        Class<?> r = m.getReturnType();
                        if (r == boolean.class || r == Boolean.class) {
                            XposedBridge.hookMethod(m, after(p -> {
                                if (Boolean.FALSE.equals(p.getResult())) return true;
                                return After.KEEP;
                            }));
                        } else if (r == int.class || r == Integer.class) {
                            XposedBridge.hookMethod(m, after(p -> {
                                if (Integer.valueOf(0).equals(p.getResult())) return 1;
                                return After.KEEP;
                            }));
                        }
                    } catch (Throwable ignored) {}
                }
            }
            try {
                List<FingerprintEngine.Hit> hits = FingerprintEngine.scanPremiumFlags(c);
                for (FingerprintEngine.Hit h : hits) {
                    try {
                        final boolean isBool = h.method.getReturnType() == boolean.class
                                || h.method.getReturnType() == Boolean.class;
                        XposedBridge.hookMethod(h.method, after(p -> {
                            if (isBool && Boolean.FALSE.equals(p.getResult())) return true;
                            if (!isBool && Integer.valueOf(0).equals(p.getResult())) return 1;
                            return After.KEEP;
                        }));
                    } catch (Throwable ignored) {}
                }
            } catch (Throwable ignored) {}
        }
    }

    // --- Network (watch only) ---
    private static void hookNetwork(ClassLoader cl) {
        hookWatch(cl, "okhttp3.Response", "body", "[Network] OkHttp.body");
        hookWatch(cl, "okhttp3.RealCall", "execute", "[Network] OkHttp.execute");
        try {
            Class<?> c = Class.forName("java.net.HttpURLConnection");
            for (Method m : c.getDeclaredMethods()) {
                if (m.getName().equals("getResponseCode") && m.getParameterTypes().length == 0) {
                    try {
                        XposedBridge.hookMethod(m, after(p -> After.KEEP));
                    } catch (Throwable ignored) {}
                }
            }
        } catch (Throwable ignored) {}
    }

    // --- Integrity (watch) ---
    private static void hookIntegrity(ClassLoader cl) {
        try {
            Class<?> c = XposedHelpers.findClass(
                    "com.google.android.play.core.integrity.IntegrityManager", cl);
            for (Method m : c.getDeclaredMethods()) {
                if (m.getName().toLowerCase().contains("integritytoken")) {
                    try {
                        XposedBridge.hookMethod(m, after(p -> After.KEEP));
                    } catch (Throwable ignored) {}
                }
            }
        } catch (Throwable ignored) {}
    }

    private static void hookBoolInt(ClassLoader cl, String cls, String method,
                                    Object forced, String tag) {
        try {
            Class<?> c = XposedHelpers.findClass(cls, cl);
            for (Method m : c.getDeclaredMethods()) {
                if (!m.getName().equals(method)) continue;
                try {
                    XposedBridge.hookMethod(m, after(p -> {
                        Object o = p.getResult();
                        if (forced instanceof Boolean && Boolean.FALSE.equals(o)) return true;
                        if (forced instanceof Integer && Integer.valueOf(0).equals(o)) return 0;
                        if (forced instanceof Integer && ((Integer) forced) == 1
                                && Integer.valueOf(0).equals(o)) return 1;
                        return After.KEEP;
                    }));
                    XposedBridge.log("[AppHook] Hook OK: " + tag);
                } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {
            XposedBridge.log("[AppHook/Safe] " + tag + " skipped (absent)");
        }
    }

    private static void hookWatch(ClassLoader cl, String cls, String method, String tag) {
        try {
            Class<?> c = XposedHelpers.findClass(cls, cl);
            for (Method m : c.getDeclaredMethods()) {
                if (!m.getName().equals(method)) continue;
                try {
                    XposedBridge.hookMethod(m, after(p -> After.KEEP));
                    XposedBridge.log("[AppHook] Hook OK: " + tag);
                } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {
            XposedBridge.log("[AppHook/Safe] " + tag + " skipped (absent)");
        }
    }
}
