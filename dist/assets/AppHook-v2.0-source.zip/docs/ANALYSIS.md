# AppHook v2.0 – تحليل آلية الاشتراك ونقاط الهوك

> هذا الملف هو **نتيجة التحليل النهائية** — يُسلَّم مع الموديول **لعدم التحليل كل مرة**.
> المحرك يقرأ `fingerprints.json` المرافق ويطابق بالبصمة بدل إعادة المسح الكامل.

## 0) بطاقة الموديول

| البند | القيمة |
|---|---|
| اسم الموديول | AppHook (الموديول الاحترافي الشامل) |
| الحزمة | `com.apphook.log` |
| رقم الإصدار | **2.0.0** (code 2) |
| أندرويد | **8.0 (API 26)** حتى **15 (API 35)** — المحرك version-agnostic حتى 16 |
| libxposed | minApi **101** / targetApi **102** |
| Xposed legacy | minVersion **82** (shim) |
| الدخول | `MainHook` (حديث: `META-INF/xposed/java_init.list`) + `LegacyHook` (قديم: `assets/xposed_init`) |
| البيئات | LSPosed / **LSPatch** / **NPatch** / **HKP** — **بدون روت** |
| الوصف المدمج | `AppHook v2.0 \| billing+features+network+integrity \| انعكاس+بصمة بلا أسماء ثابتة \| آمن ضد الكراش \| LSPatch/NPatch/HKP بلا روت` |

## 1. نموذج التحقق في التطبيقات المستهدفة

| النموذج | آلية العمل | نقاط الضعف | مثال |
|---------|-----------|------------|------|
| **محلي بالكامل** | المنطق داخل APK، يُخزَّن في SharedPreferences أو متغيرات | Hook مباشر على الدالة المنطقية | `isVip()`, `isPremium()` |
| **خادمي بالكامل** | الخادم يتحقق من Receipt ويعيد حالة الاشتراك | اعتراض استجابة HTTPS | `checkSubscription` API |
| **هجين (الأكثر شيوعاً)** | تحقق محلي + تحقق خادمي عند التزامن | يجب تجاوز الطبقتين معاً | Billing + Server Sync |
| **Google Play Billing** | `BillingClient` + `Purchase.getPurchaseState()` | Hook على `getPurchaseState` وإرجاع 0 | PBL v5-v8 |
| **RevenueCat** | `CustomerInfo.getEntitlements()` + `isActive()` | Hook على `EntitlementInfo.isActive` | RevenueCat SDK |

## 2. نقاط الهوك الرئيسية (Hook Points)

### 2.1 Google Play Billing Library (PBL)

| الفئة | الدالة | المُعدّات | طريقة الهوك | الهشاشة | الأثر الجانبي |
|-------|--------|-----------|-------------|---------|---------------|
| `com.android.billingclient.api.Purchase` | `getPurchaseState()` | `()` → int | `intercept` → `proceedWith(0)` / `setResult(0)` | مستقرة (PBL v5-v8) | قد يتخطى Acknowledge → نغطيه بـ `isAcknowledged→true` |
| `Purchase` | `isAcknowledged()` | `()` → boolean | إجبار `true` | مستقرة | منع إعادة الشراء |
| `BillingClient` | `queryPurchasesAsync()` | `(Params, Listener)` → void | مراقبة before/after (الحقن الكامل هش) | مستقرة | تزامن خادمي |
| `Purchase.PurchasesResult` | `getPurchasesList()` | `()` → List | مراقبة فقط | مستقرة | قائمة فارغة |
| `BillingClient` | `isReady()` | `()` → boolean | إجبار `true` | مستقرة | الاتصال |

PBL v7 مدعوم حتى أغسطس 2026، وv8 منذ يونيو 2025. فئات `Purchase`/`BillingClient` محمية بقواعد keep → مستقرة للهوك.

### 2.2 RevenueCat SDK

| الفئة | الدالة | المُعدّات | طريقة الهوك | الهشاشة | الأثر الجانبي |
|-------|--------|-----------|-------------|---------|---------------|
| `com.revenuecat.purchases.EntitlementInfo` | `isActive()` | `()` → boolean | إجبار `true` | مستقرة | يحتاج تصفير billingIssue |
| `EntitlementInfo` | `getBillingIssueDetectedAt()` | `()` → Date | إجبار `null` | مستقرة | Grace Period |
| `CustomerInfo` | `getEntitlements()` | `()` → Entitlements | مراقبة فقط | R8-sensitive | مزامنة الخادم |

### 2.3 اعتراض الشبكة (OkHttp / HTTPS)

| الفئة | الدالة | طريقة الهوك | الهشاشة | ملاحظة |
|-------|--------|-------------|---------|--------|
| `okhttp3.Response` | `body()` | مراقبة (لا نستهلك one-shot body) | R8-sensitive | تعديل الـ Proxy اختياري |
| `okhttp3.RealCall` | `execute()` | مراقبة URL+code | مستقرة | تدفق الطلب |
| `java.net.HttpURLConnection` | `getResponseCode()` | مراقبة فقط (لا نجبر 200) | مستقرة | إجبار 200 يكسر التدفق |
| `RealInterceptorChain` | `proceed()` | **نتجنبه عمداً** | هشّ (internal) | يُكسر بين إصدارات OkHttp |

### 2.4 Play Integrity

| الفئة | الدالة | طريقة الهوك | الهشاشة |
|-------|--------|-------------|---------|
| `IntegrityManager` | `requestIntegrityToken()` | مراقبة افتراضياً (التعديل العدواني يكسر التطبيق) | R8-sensitive |
| `StandardIntegrityManager` | وجود/مراقبة | رصد فقط | R8-sensitive |

### 2.5 أعلام Premium المحلية

| النمط | طريقة الهوك | الهشاشة |
|-------|-------------|---------|
| `isPremium/isVip/isPro/hasPremium/isSubscribed/...` → boolean | إجبار `true` | R8-sensitive → نغطيه بالمسح الجزئي + مسح البصمة الشامل |
| `getVipStatus` وأشباهها → int | إجبار `1` | نفس الغطاء |

## 3. مخاطر الكسر عند التحديث القادم

| الأولوية | نقطة الهوك | السبب | الحل المطبق |
|----------|-----------|-------|------|
| **P0** | `Purchase.getPurchaseState` | PBL v9 قد يغير enum | بصمة مرنة + fallback `getPurchase*` + تجاهل آمن |
| **P0** | `queryPurchasesAsync` | تغيير التوقيع في v9 | مسح كل overloads بالاسم + مراقبة بدل حقن |
| **P1** | `EntitlementInfo.isActive` | RevenueCat v9+ قد يعيد التسمية | fallback `active` + مسح شامل |
| **P1** | `Response.body` | OkHttp v5/R8 | مراقبة + تخطي آمن |
| **P2** | دوال Premium المخصصة | R8 يعيد التسمية | قاموس جزئي + `scanPremiumFlags()` الشامل |
| **P2** | Integrity | Google تغير API | مطابقة جزئية `integritytoken` + مراقبة |

## 4. استراتيجية تجنب الكراش (مطبقة بالكامل)

1. **ExceptionMode.PROTECTIVE** على كل Hook حديث — أي استثناء يُلتقط ويستمر التطبيق.
2. **LegacyBridge يدوي**: كل `hookMethod` داخل try/catch + جسم الهوك داخل try/catch.
3. **findClassQuiet**: `Class.forName(..., false, cl)` تُرجع null بدل `ClassNotFoundError`.
4. **نطاق آمن**: استثناء `android / systemui / gms / vending / الموديول نفسه` لمنع البوت لوب.
5. **Packed apps**: الهوك الحقيقي في `onPackageReady.getClassLoader()` (بعد فك الـ stub)، لا في ClassLoader مبكر.
6. **لا تعديل للقيم الحرجة**: `getPurchasesList`/`getResponseCode`/`Integrity` مراقبة فقط.
7. **تسجيل شامل**: `[Billing] / [Feature] / [Network] / [Safe]` مع الحدث والوسائط والنتيجة.

## 5. آلية القياس (Metrics)

| المقياس | التنفيذ | مثال السجل |
|---------|---------|-----------|
| استدعاءات الفوترة | `logBilling(event, args, result)` | `[Billing] getPurchaseState args=0 result=2` ثم `-> forced 0` |
| الميزات المفتوحة | عدّاد `AtomicInteger` لكل ميزة | `[Feature] isPremium unlocked: 5 times` |
| الشبكة | URL + code + size | `[Network] GET /api/sub -> 200 (-1B)` |
| عزل الكراش | PROTECTIVE + try/catch | `[Safe] X skipped: method-not-found` |

## 6. كاش البصمة — لعدم التحليل كل مرة

- `docs/fingerprints.json`: قاعدة البصمات المستقرة (تُقرأ وقت التطوير/المراجعة).
- وقت التشغيل: `findClassQuiet + findMethodByFingerprint + scanPremiumFlags` مع
  سلسلة: **مستقر → جزئي → مسح شامل → تخطي آمن**.
- أي Hit جديد يُسجل في اللوج بصيغة `Hook OK: <event> -> <method>` فيُضاف للـ JSON في الإصدار التالي.

## 7. البناء والتحقق

```bash
cd AppHook
./gradlew :app:assembleRelease
# الناتج: app/build/outputs/apk/release/app-release.apk
adb install -r app/build/outputs/apk/release/app-release.apk
# LSPosed: فعّل AppHook + حدد النطاق
# السجل المتوقع: "AppHook v2.0 | billing+features+..."
```

```bash
# حزمة السورس
zip -r AppHook-v2.0-source.zip AppHook/ -x "*/build/*" "*/.gradle/*"
```

## 8. التوافق والصيانة

- أندرويد 8.0–15، libxposed 101→102، PBL v5–v8، OkHttp 3/4، RevenueCat v7/v8.
- كل Feature في ملف مستقل (`BillingHook / RevenueCatHook / FeatureHook / NetworkHook / IntegrityHook`)
  + `SafeHook` + `FingerprintEngine` مشتركة → إضافة ميزة = ملف جديد + سطر في `MainHook.installAll`.
- `MainHook.inScope()` للتضييق على حزم معينة عند الحاجة.
